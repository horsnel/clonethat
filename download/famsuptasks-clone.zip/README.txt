CloneForge Clone — famsuptasks.com
==================================
Source requested : https://famsuptasks.com/register
Final URL        : https://famsuptasks.com/ (auto-healed: /register renders a client-side 404;
                   the real Sign-Up form is a modal captured as index--sign-up.html)
Captured pages   : index.html          (homepage)
                   index--sign-up.html (Sign-Up modal state  <- the register form)
                   index--log-in.html  (Log-In modal state)
Render mode      : headless Chromium (JS rendered) + interaction replay
Detected stack   : Svelte, Tailwind CSS, Meta Pixel, Cloudflare
Brand color      : #ff7300

HOW TO USE
----------
The root of this folder IS the site (index.html + assets/). To view:
  - Just open index.html in a browser (assets are relative), or
  - Serve it:  python3 -m http.server 8080   then visit http://localhost:8080

  index--sign-up.html contains the "Create an account" register form
  captured by replaying the Sign-Up button click on the original site.

  single-html/  — each page as ONE self-contained file (assets inlined as base64),
                  no assets folder needed.
  _screenshots/ — screenshots of the ORIGINAL site pages for fidelity comparison.
  clone-meta.json — full engine metadata (analysis, warnings, timestamps).

AI REBUILD (bonus)
------------------
rebuild/ contains AI-generated clean rewrites of the captured pages as
hand-readable Tailwind code (.html) + React components (.tsx).
They need only the Tailwind CDN (already included) - open rebuild/index.html
in a browser; images resolve via the assets/ folder at the site root.
